<?php $this->load->view('header') ?>
<?php $this->load->view('common_link') ?>
<?php $this->load->view($content_view) ?>
<?php $this->load->view('footer') ?>