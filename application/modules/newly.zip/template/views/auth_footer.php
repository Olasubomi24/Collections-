<script src="<?= base_url('assets/bundles/libscripts.bundle.js') ?>"></script>
<script src="<?= base_url('assets/bundles/vendorscripts.bundle.js') ?>"></script>


</body>


</html>